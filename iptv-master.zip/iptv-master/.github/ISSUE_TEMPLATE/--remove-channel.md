---
name: "\U0001F6A8 Remove Channel"
about: Request to remove a channel
title: 'Remove: xxx'
labels: DMCA
assignees: ''
---

<!-- Please fill out the information in this issue template so that we can
efficiently process your request -->

**_Channel Name:_** xxx
**_DMCA Notice (link):_** xxx
