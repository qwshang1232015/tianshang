---
name: "\U0001F4FA Channel Request"
about: Request to add a channel to the playlist
title: ''
labels: channel request
assignees: ''
---

<!-- Please fill out the issue template as much as you can so we could efficiently process your request -->

<!-- IMPORTANT: An issue may contain a request for only one channel, otherwise it will be closed -->

**Channel Name:** xxx
**Country:** xxx
**Language:** xxx
**Website:** xxx
**Stream URL (optional):** xxx
**Notes (optional):** xxx
